<?php
/*  //$json='[{"nombreUsuariop":"jajaja"}]';

//$con = mysqli_connect('localhost', 'root', '', 'desarrollo');
var_dump($con);
$info = json_decode($nombreUsuariop, true);

header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
 






echo (info);

//Usuario......

$nombreUsuariopa = mysqli_real_escape_string($con, $info-> nombreUsuariop);
//$claveUsuariop = mysqli_real_escape_string($con, $info-> claveUsuariop);


$query = "INSERT INTO `usuarioprueba`(nombreUsuariop) values $'omb'eUsuariopa)";

if(mysqli_query($con, $query)){
	echo "inserto";
}else{
	echo 'Failed';
}*/

// header('Content-type: application/json');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: PUT, GET, POST");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");


$postdata = file_get_contents('php://input');
$data1 = json_decode($postdata);
$data = $data1->nombreUsuariop;

// $data = $data1['nombreUsuariop'];


//$datosclientes = json_decode($json, true);

$con = mysqli_connect('localhost', 'root', '', 'mydb');


$queryinsert = "INSERT INTO usuarioprueba (nombreUsuariop)
values ('test')";  

$result = mysqli_query($con, $queryinsert);







?>
